var load_nav = "nav.html?timestamp=" + new Date().getTime();
var load_footer = "footer.html?timestamp=" + new Date().getTime();
$("#load-nav").load(load_nav);
$("#load-footer").load(load_footer);